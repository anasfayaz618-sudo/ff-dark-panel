require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const path = require('path');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET to a random secret of at least 32 characters.');
  process.exit(1);
}
const app = express();
const db = new Database(path.join(__dirname, 'licenses.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS licenses(id INTEGER PRIMARY KEY, license_key TEXT UNIQUE NOT NULL, device_id TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS activations(id INTEGER PRIMARY KEY, license_id INTEGER, device_id TEXT NOT NULL, activated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
`);
app.use(helmet({contentSecurityPolicy: false}));
app.use(express.json({limit:'20kb'}));
app.use(rateLimit({windowMs: 60_000, limit: 100}));
const adminLimiter = rateLimit({windowMs: 15*60_000, limit: 10});
const tokenFor = a => jwt.sign({id:a.id, username:a.username}, process.env.JWT_SECRET, {expiresIn:'8h'});
function auth(req,res,next) {
  try { req.admin = jwt.verify((req.headers.authorization||'').replace(/^Bearer\s+/i,''), process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({error:'Admin authentication required'}); }
}
app.get('/api/status', (req,res) => res.json({setupRequired: db.prepare('SELECT COUNT(*) n FROM admins').get().n===0}));
app.post('/api/setup', adminLimiter, async (req,res) => {
  const {username,password} = req.body || {};
  if (db.prepare('SELECT COUNT(*) n FROM admins').get().n !== 0) return res.status(409).json({error:'Admin already configured'});
  if (!/^[a-zA-Z0-9_]{4,24}$/.test(username||'') || typeof password!=='string' || password.length<12)
    return res.status(400).json({error:'Use a 4–24 character username and password of at least 12 characters'});
  const hash = await bcrypt.hash(password, 12);
  try {
    const info = db.prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)').run(username,hash);
    const admin = {id:info.lastInsertRowid,username};
    res.json({token:tokenFor(admin),username});
  } catch { res.status(409).json({error:'Username unavailable'}); }
});
app.post('/api/login', adminLimiter, async (req,res) => {
  const a = db.prepare('SELECT * FROM admins WHERE username=?').get(req.body?.username||'');
  if (!a || !await bcrypt.compare(req.body?.password||'',a.password_hash)) return res.status(401).json({error:'Invalid credentials'});
  res.json({token:tokenFor(a),username:a.username});
});
app.post('/api/admin/keys', auth, (req,res) => {
  const count = Math.min(100, Math.max(1, Number(req.body?.count)||1));
  const insert = db.prepare('INSERT INTO licenses(license_key) VALUES(?)');
  const keys=[];
  for(let i=0;i<count;i++){
    const key='FFDP-'+require('crypto').randomBytes(6).toString('hex').toUpperCase();
    insert.run(key); keys.push(key);
  }
  res.json({keys});
});
app.get('/api/admin/keys', auth, (req,res) => {
  res.json(db.prepare('SELECT id,license_key,device_id,active,created_at FROM licenses ORDER BY id DESC LIMIT 500').all());
});
app.post('/api/admin/keys/:id/revoke', auth, (req,res) => {
  const info=db.prepare('UPDATE licenses SET active=0 WHERE id=?').run(req.params.id);
  res.json({revoked:info.changes===1});
});
app.post('/api/activate', (req,res) => {
  const {key,deviceId}=req.body||{};
  if(typeof key!=='string'||typeof deviceId!=='string'||deviceId.length<8||deviceId.length>128) return res.status(400).json({error:'Invalid activation details'});
  const lic=db.prepare('SELECT * FROM licenses WHERE license_key=?').get(key.trim().toUpperCase());
  if(!lic||!lic.active) return res.status(403).json({error:'Invalid or revoked key'});
  if(lic.device_id && lic.device_id!==deviceId) return res.status(403).json({error:'This key is already linked to another device'});
  db.prepare('UPDATE licenses SET device_id=? WHERE id=?').run(deviceId,lic.id);
  db.prepare('INSERT INTO activations(license_id,device_id) VALUES(?,?)').run(lic.id,deviceId);
  res.json({activated:true});
});
app.get('/api/admin/logs', auth, (req,res) => res.json(db.prepare('SELECT license_id,device_id,activated_at FROM activations ORDER BY id DESC LIMIT 300').all()));
app.get('/admin', (req,res) => res.sendFile(path.join(__dirname,'admin.html')));
app.listen(process.env.PORT||3000,()=>console.log('FF DARK PANEL API ready'));
