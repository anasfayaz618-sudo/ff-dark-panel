package com.ffdarkpanel.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.UUID

class MainActivity : Activity() {
    private val client=OkHttpClient()
    private lateinit var keyInput: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("ffdp", MODE_PRIVATE) }
    private fun deviceId(): String {
        var id=prefs.getString("device_id",null)
        if(id==null){ id=UUID.randomUUID().toString(); prefs.edit().putString("device_id",id).apply() }
        return id
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }
    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply { orientation=1; setPadding(28,36,28,24); setBackgroundColor(Color.rgb(8,13,10)) }
    }
    private fun label(t:String,size:Float=16f)=TextView(this).apply { text=t; textSize=size; setTextColor(Color.rgb(80,255,55)); setPadding(0,12,0,12) }
    private fun showLogin(){
        val root=baseLayout()
        root.addView(label("FF DARK PANEL",26f)); root.addView(label("ONLINE DEVICE ACTIVATION",12f))
        keyInput=EditText(this).apply { hint="Enter your device activation key"; setSingleLine(); setTextColor(-1); setHintTextColor(0xff8ca18c.toInt()) }
        root.addView(keyInput)
        val b=Button(this).apply { text="ACTIVATE DEVICE"; setOnClickListener { activate() } }; root.addView(b)
        status=label("Device ID: ${deviceId().take(8)}…",12f); root.addView(status)
        setContentView(root)
    }
    private fun activate(){
        val key=keyInput.text.toString().trim()
        if(key.isEmpty()){status.text="Enter an activation key";return}
        val body=JSONObject().put("key",key).put("deviceId",deviceId()).toString()
        val req=Request.Builder().url(ApiConfig.BASE_URL+"api/activate").post(body.toRequestBody("application/json".toMediaType())).build()
        status.text="Checking license…"
        client.newCall(req).enqueue(object:Callback{
            override fun onFailure(call:Call,e:IOException){runOnUiThread{status.text="Connection failed. Check server URL and internet."}}
            override fun onResponse(call:Call,response:Response){
                val ok=response.isSuccessful; response.close()
                runOnUiThread { if(ok){ prefs.edit().putBoolean("activated",true).apply(); showActivated() } else status.text="Activation rejected. Check key or contact admin." }
            }
        })
    }
    private fun showActivated(){
        val root=baseLayout(); root.addView(label("ACTIVATION SUCCESSFUL",22f))
        root.addView(label("The training overlay is ready.",14f))
        root.addView(Button(this).apply{text="ENABLE FLOATING PANEL";setOnClickListener{
            if(!Settings.canDrawOverlays(this@MainActivity)){
                startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),10)
            } else startService(Intent(this@MainActivity,OverlayService::class.java))
        }})
        root.addView(label("This panel provides standalone practice controls only. It does not modify Free Fire.",12f))
        setContentView(root)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==10&&Settings.canDrawOverlays(this))startService(Intent(this,OverlayService::class.java))}
}
