package com.ffdarkpanel.app
object ApiConfig {
    // Replace with your deployed HTTPS API URL. Keep the trailing slash.
    const val BASE_URL = "https://YOUR-DOMAIN.example/"
}
