package com.ffdarkpanel.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class OverlayService: Service(){
 private lateinit var wm:WindowManager
 private var panel:View?=null
 override fun onBind(intent:Intent?):IBinder?=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { if(panel==null) showPanel(); return START_NOT_STICKY }
 private fun bg(color:Int):GradientDrawable=GradientDrawable().apply{setColor(color);cornerRadius=22f;setStroke(2,0xff39ff14.toInt())}
 private fun showPanel(){
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val box=LinearLayout(this).apply{orientation=1;setPadding(18,14,18,14);background=bg(0xee080d0a)}
  val header=TextView(this).apply{text="☰  FF DARK PANEL     [—]";textSize=17f;setTextColor(0xff39ff14.toInt());setPadding(8,8,8,18)}
  box.addView(header)
  header.setOnTouchListener(object:View.OnTouchListener{
   var sx=0f;var sy=0f;var px=0;var py=0
   override fun onTouch(v:View,e:MotionEvent):Boolean{val lp=panel?.layoutParams as? WindowManager.LayoutParams?:return false
    when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;px=lp.x;py=lp.y;return true}
    MotionEvent.ACTION_MOVE->{lp.x=px+(e.rawX-sx).toInt();lp.y=py+(e.rawY-sy).toInt();wm.updateViewLayout(panel,lp);return true}}
    return false
   }})
  val close=Button(this).apply{text="MINIMIZE / CLOSE";setOnClickListener{stopSelf()}}
  box.addView(close)
  listOf("Aim sensitivity trainer","Visual reaction practice","Movement practice timer","Reload timing tracker","Location display (device permission)","Keybind reference").forEach{ name->
   val row=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL}
   row.addView(TextView(this).apply{text=name;textSize=13f;setTextColor(-1);layoutParams=LinearLayout.LayoutParams(0,-2,1f)})
   row.addView(Switch(this).apply{text="";isChecked=false;buttonTintList=android.content.res.ColorStateList.valueOf(0xff39ff14.toInt())})
   box.addView(row)
  }
  val type=if(android.os.Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=30;y=120}
  panel=box;wm.addView(box,lp)
 }
 override fun onDestroy(){if(panel!=null){wm.removeView(panel);panel=null};super.onDestroy()}
}
