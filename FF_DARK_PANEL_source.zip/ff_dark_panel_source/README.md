# FF DARK PANEL — starter source

This is a source-code starter, not a compiled APK. It contains:
- Android Kotlin app with online activation and a movable floating training panel.
- Node.js license/admin API with first-run admin setup, per-device keys, revoke, and activation logs.
- No game memory access, injection, ESP, aimbot, teleport, anti-cheat bypass, or other game cheats.

## Backend
Requires Node.js 20+.
1. `cd server && npm install`
2. `cp .env.example .env` and set a long random `JWT_SECRET`.
3. `npm start`
4. Open `http://localhost:3000/admin` to create the first admin account.
5. Use the admin dashboard to generate device keys.

For a real deployment, host the API behind HTTPS. Set rate limits, back up `server/data/licenses.db`, and keep `.env` private.

## Android
Open the `android` folder in Android Studio (recent stable version), let Gradle sync, then set `BASE_URL` in `android/app/src/main/java/com/ffdarkpanel/app/ApiConfig.kt` to your HTTPS server URL.
Build > Build APK(s).

The app requests Android's "display over other apps" permission before showing its floating panel. Android versions and manufacturer battery restrictions vary, so test on target devices. This starter has not been compiled or device-tested in this environment.
